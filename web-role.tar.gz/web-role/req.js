function randomInt (low, high) {
    return Math.floor(Math.random() * (high - low) + low);
}

n = randomInt(0,2)
console.log(n)
if(n==1)
{
var request = require('request');
request('http://localhost:49162', function (error, response, body) {
  console.log('error:', error); // Print the error if one occurred 
  console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received 
  console.log('body:', body); // Print the HTML for the Google homepage. 
});
}

else
{
  var request = require('request');
  request('http://localhost:49161', function (error, response, body) {
  console.log('error:', error); // Print the error if one occurred 
  console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received 
  console.log('body:', body); // Print the HTML for the Google homepage. 
});
}
