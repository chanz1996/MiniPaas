var http = require('http');
url = require('url');
n = 0
http.createServer(function (req, res) {
  q = url.parse(req.url, true);
  var qdata = q.query;
  cat = qdata.data;
  console.log(cat);
  res.writeHead(200, {'Content-Type': 'text/plain'});
  a = "";
 
  console.log(n)
  
if(n==0)
{
var request = require('request');
my_url = 'http://localhost:49170?data='+cat;
//console.log(my_url);
request(my_url, function (error, response, body) {
  console.log('error:', error); // Print the error if one occurred 
  console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received 
  console.log('body:', body); // Print the HTML for the Google homepage.
  var responseBody = {
  body: body
  };
  res.end(JSON.stringify(responseBody)); 
});
n++;
console.log(n);
}

else if(n==1)
{
  var request = require('request');
  my_url = 'http://localhost:49171?data='+cat;
  //console.log(my_url);
  request(my_url, function (error, response, body) {
  console.log('error:', error); // Print the error if one occurred 
  console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received 
  console.log('body:', body); // Print the HTML for the Google homepage.
  var responseBody = {
  body: body
  };
  res.end(JSON.stringify(responseBody)); 
});
n++;
console.log(n);
}

else 
{
  var request = require('request');
  my_url = 'http://localhost:49172?data='+cat;
  //console.log(my_url);
  request(my_url, function (error, response, body) {
  console.log('error:', error); // Print the error if one occurred 
  console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received 
  console.log('body:', body); // Print the HTML for the Google homepage. 
   var responseBody = {
  body: body
  };
  res.end(JSON.stringify(responseBody)); 
});
n = 0;
console.log(n);
}

 //res.end();
 //res.end(a,'\n');
}


).listen(8080, '172.18.0.1');
console.log('Server running at http://:172.18.0.1:8080/');
