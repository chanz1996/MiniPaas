var http = require('http');
n = 0
http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('Web role\n');
  console.log(n)
if(n==0)
{
var request = require('request');
request('http://localhost:49161', function (error, response, body) {
  console.log('error:', error); // Print the error if one occurred 
  console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received 
  console.log('body:', body); // Print the HTML for the Google homepage. 
});
n++;
console.log(n);
}

else if(n==1)
{
  var request = require('request');
  request('http://localhost:49162', function (error, response, body) {
  console.log('error:', error); // Print the error if one occurred 
  console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received 
  console.log('body:', body); // Print the HTML for the Google homepage. 
});
n++;
console.log(n);
}

else 
{
  var request = require('request');
  request('http://localhost:49163', function (error, response, body) {
  console.log('error:', error); // Print the error if one occurred 
  console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received 
  console.log('body:', body); // Print the HTML for the Google homepage. 
});
n = 0;
console.log(n);
}

}).listen(8080, '172.18.0.1');
console.log('Server running at http://:172.18.0.1:8080/');
